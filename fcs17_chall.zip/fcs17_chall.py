
from flag import FLAG

charset = "กขฃคฅฆงจฉชซญฎฏฐณดตถทธนบปผฝพฟภมยรลวศษสหอ"

def base39_encode(s):
    n = int(s.hex(), 16)
    r = ''

    while n > 0:
        r += charset[n % 39]
        n = n // 39
    
    return r[::-1]

def base39_decode(s):
    # I lost it. Please help me fix.
    pass

message = "Hello Mr. Somchai Thanathack <Senior IT Security>. We develop a new encoding techenology for Siam Don Hack Bank. Please kindly review. %s" % FLAG
print(base39_encode(message.encode()))
