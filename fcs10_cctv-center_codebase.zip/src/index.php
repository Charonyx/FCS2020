<?php 
    session_start();
    if(isset($_SESSION["data"])) {
        require_once("utility.php");
        unserialize(load_sessionz());
    }
?>
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <title>SDH Bank | CCTV Center</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
    <meta name="description" content="Siam Donhack Bank CCTV Center Page">
    <meta name="keywords" content="sdh">
    <meta name="author" content="sth">

    <!-- sortcut icon -->
    <link rel='shortcut icon' href="/assets/images/fevicon.png" type="image/ico" />
    <link rel="apple-touch-icon" sizes="57x57" href="/assets/images/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/assets/images/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/assets/images/apple-touch-icon-114x114.png">

    <!-- theme color -->
    <meta name="theme-color" content="#BCD531">

    <!-- fonts -->
    <link href="/assets/css/poppins.css" rel="stylesheet">
    <link href="/assets/css/montserrat.css" rel="stylesheet">
    <link href="/assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="/assets/css/icofont.css" rel="stylesheet">

    <!-- animation -->
    <link href="/assets/css/animate.min.css" rel="stylesheet">
    <!-- owl carousel -->
    <link href="/assets/css/owl.carousel.css" rel="stylesheet">
    <!-- bootstrap-->
    <link href="/assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- style css -->
    <link href="/assets/css/style.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

    <![endif]-->
    <script src="/assets/css/sweetalert2.js"></script>
</head>

<body>

<!-- site loader -->
<div class="loader"></div>
<!-- end site loader -->

<!--header start-->
<div class="header-fix"></div>
<header class="header-dark">
    <div class="navbar navbar-default yamm container">
        <!-- navbar-header -->
        <div class="navbar-header">
            <!-- menu Toggle -->
            <button class="navbar-toggle" data-target="#navbar-collapse-grid" data-toggle="collapse" type="button"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            <ul>
                <li class="search-open hide-md">
                    <!-- serachbar Toggle for mobile only -->
                    <a href="#"><i class="fa fa-search"></i></a>
                </li>
                <li>
                    <!--company logo-->
                    <a class="navbar-brand" href="/"><img alt="logo" src="/assets/images/logo.png"></a>
                </li>
            </ul>
        </div><!--end navbar-header -->

        <!--Navigation Start-->
        <nav class="navbar-collapse collapse" id="navbar-collapse-grid">
            <ul class="nav navbar-nav navbar-right" id="mainNav">
                <li>
                    <a class="page-link" href="/">Home</a>
                </li>
                <li>
                    <?php 
                        if(isset($_SESSION["username"])){
                            echo "<a class=\"page-link\" href=\"/logout.php\">Logout</a>";
                        }else{
                            echo "<a class=\"page-link\" href=\"/login.php\">Login</a>";
                        }
                    ?>
                </li>
            </ul>
        </nav>
        <!--Navigation end-->
    </div>
</header>
<!--Header End-->

<!-- page header -->
<section class="page-head">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-header-title">
                    SDH Bank | CCTV Center
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end page header -->


<!-- blog content -->
<div class="blod-content">
    <div class="container">
        <div th:fragment="content_home" class="blog-left">
            <h1 class="register-form-title">CCTV Center</h1>
            <?php 
            if(isset($_SESSION["mes"])) 
                echo "<div class=\"alert alert-secondary\" style=\"background: gray;color: white\" role=\"alert\">". htmlentities($_SESSION["mes"]) . "</div>"; 
                unset($_SESSION["mes"]);
                if(isset($_SESSION["username"])) {
                echo "<h4>Hi, " . htmlentities($_SESSION["username"]). "</h4>";
                echo '
                <table class="table">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Camera Name</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td scope="row" colspan="3" style="text-align: center">Camera Not Found</td>
        </tr>
    </tbody>
</table>';
                } else {
                    echo "<h4>Please Login</h4>";
                }

            ?>
            
        </div>
    </div>
</div>
<!-- blog content -->

<!--footer bottom-->
<div class="footer-bottom">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- © All rights reserved for <a href="https://sth.sh" target="_blank">Siam Thanat Hack Company Limited</a> -->
            </div>
        </div>
    </div>
</div>
<!-- end footer bottom-->

<!--back to to -->
<a class="BackToTop" href="#">
    <i class="fa fa-angle-up"></i>
</a>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="/assets/js/jquery.min.js"></script>
<!-- bootstrap-min-js -->
<script src="/assets/js/bootstrap.min.js"></script>
<!-- waypoints-min-js -->
<script src="/assets/js/waypoints.min.js"></script>
<!-- counterup-min-js -->
<script src="/assets/js/jquery.counterup.min.js"></script>
<!-- jquery.touchSwipe js -->
<script src="/assets/js/jquery.touchSwipe.min.js"></script>
<!-- wow Animation js -->
<script src="/assets/js/wow.js"></script>
<!-- owl carasol js -->
<script src="/assets/js/owl.carousel.js"></script>
<!--smoth-scroll -->
<script src="/assets/js/smoth-scroll.js"></script>
<!-- validate js -->
<script src="/assets/js/jquery.validate.min.js"></script>
<!-- custom js -->
<script src="/assets/js/app.js"></script>

</body>

</html>
