<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: http://".$_SERVER['SERVER_NAME']."/index.php");
    exit;
}

if(isset($_SESSION["username"])){
    header("Location: http://".$_SERVER['SERVER_NAME']."/index.php");
    exit;
}

require_once("utility.php");

$user = $_POST["user"];
$pass = $_POST["pass"];

if (is_null($user) || empty($user)) {
    $_SESSION["mes"] = "We need to know your username!";
    header("Location: http://".$_SERVER['SERVER_NAME']."/login.php");
    exit;
}

if (is_null($pass)|| empty($pass)) {
    $_SESSION["mes"] = "We need to know your password!";
    header("Location: http://".$_SERVER['SERVER_NAME']."/login.php");
    exit;
}

$_SESSION["uuid"] = save_sessionz($user, $pass);
header("Location: http://".$_SERVER['SERVER_NAME']."/index.php");