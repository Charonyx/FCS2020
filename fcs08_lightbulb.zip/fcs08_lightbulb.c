#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

// gcc -no-pie -static lightbulb.c -o lightbulb

void load_config(uint8_t *config) {
}

void save_config(uint8_t *config) {
}

int set_light(uint8_t l_id, uint8_t val) {
    uint8_t config[10] = {0};

    load_config(config);

    if (val > 255) {
        printf("Invalid Light Bulb Value\n");
        exit(1337);
    }

    config[l_id - 1] = val;

    save_config(config);
    return 0;
}

char password[100];

int main() {
    uint8_t l_id, val;
    printf("!! Lightbulb !!\n");
    printf("Gimme a password: ");
    fflush(stdout);
    scanf("%s", password);
    if (strcmp(password, "Thisisverysecurepassword.") != 0) return 0;

    while (1) {
        printf("Light <L_ID:1-10> <VAL:0-255>: ");
        fflush(stdout);
        scanf("%hhd %hhd", &l_id, &val);
        if (l_id == 0) {
            break;
        }
        set_light(l_id, val);
    }
    return 0;
}
